<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="modul/style.css">
	<style>
		.trims{
			width: 600px;
			text-align: center;
			margin: 10% auto;
			font-size: 30px;
			background-color: darkseagreen;
			color: white;
		}
		.trims a{
			font-size: 0.6em;
		}
	</style>
</head>
<body style="background-color: darkseagreen;">
	
<div class="trims">
	<img src="img/ucing.png" width="200px">
	<h3>Terima kasih sudah berbelanja di toko kami</h3>
	<a href="index.php" class="tmbl hijau">Belanja lagi yuk </a>
	<p>&copy; WarungKembang</p>
</div>

</body>
</html>