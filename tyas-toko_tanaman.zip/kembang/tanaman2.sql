-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Okt 2021 pada 07.30
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tanaman2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ongkir`
--

CREATE TABLE `ongkir` (
  `id` int(11) NOT NULL,
  `jarak` int(11) NOT NULL,
  `ongkir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ongkir`
--

INSERT INTO `ongkir` (`id`, `jarak`, `ongkir`) VALUES
(1, 1, 10000),
(2, 2, 20000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` int(20) NOT NULL,
  `jumlah` int(15) NOT NULL,
  `pembeli` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id`, `nama`, `harga`, `jumlah`, `pembeli`, `alamat`, `telepon`) VALUES
(10, 'bunga lili', 20000, 2, 'Tyas', 'jalan alamanda no 30 jaten', 2147483647),
(13, 'tanaman anggur', 250000, 1, 'satria', 'surakarta', 27232211),
(14, 'bunga putih', 100000, 1, 'krimi', 'karangmalang juwiring', 2147483647),
(16, 'bunga putih', 100000, 1, 'tyas', 'pedan klaten', 2147483647),
(17, 'bunga putih', 100000, 1, 'kiki', 'klaten', 2147483647);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `harga` int(13) NOT NULL,
  `tag` varchar(11) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama`, `isi`, `gambar`, `harga`, `tag`, `waktu`) VALUES
(4, 'bunga lili', 'bunga putih cantik', 'img/kembang1.jpg', 20000, 'bunga', '2021-10-30 05:24:54'),
(6, 'bunga hias', 'bunga hias aethetic cocok untuk menghiasi kebunmu', 'img/hias2.jpg', 50000, 'bunga', '2021-10-30 05:25:06'),
(8, 'tanaman hias', 'tanaman aesthetic cocok menghiasi halaman rumah anda', 'img/hias1.jpg', 50000, 'bunga', '2021-10-30 05:25:16'),
(9, 'bunga putih', 'bunga putih angsa ', 'img/kembang3.jpg', 100000, 'bunga', '2021-10-30 05:25:29'),
(11, 'pohon jeruk', 'pohon jeruk bonsai cocok untuk menghiasi kebun mu', 'img/jeruk.png', 150000, 'bibit', '2021-10-30 05:26:17'),
(12, 'pohon belimbing', 'pohon belimbing bonsai', 'img/blimbing.jpg', 200000, 'bibit', '2021-10-30 05:26:32'),
(13, 'tanaman anggur', 'tanaman anggur bonsai', 'img/anggur.jpg', 250000, 'bibit', '2021-10-30 05:26:44'),
(14, 'tanaman cabai', 'tanaman cabai bonsai', 'img/lombok.jpg', 200000, 'bibit', '2021-10-30 05:26:55'),
(15, 'tanaman apel', 'tanaman apel bonsai', 'img/apel.jpg', 200000, 'bibit', '2021-10-30 05:27:06'),
(16, 'tanaman strawberry', 'tanaman strawberry', 'img/strawberry.jpg', 200000, 'bibit', '2021-10-30 05:27:19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(4, 'tyas', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
