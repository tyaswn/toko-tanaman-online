<?php 
require_once 'pembeli/view.php';
headerku();
$tampil = tampil();
 ?>

<div class="banner">
	<div class="konten">
		<div class="info">
			<img src="img/logokembang.png" width="300px" alt="">
			<p>
				Toko warungkembang hiasi kebunmu dengan tanaman hias aesthetic</p>
			<p>Atau datang langsung ke toko kami :</p>
			<p>di Jalan Gatot Kaca no.100 Laweyan Surakarta
			<p><img src="img/money.png" width="20px" style="float: left;"> Contact Person :</p>
			<p>instagram @katalogWarungKembang</p>
			<p style="color:blue;">No.rek : 0300642055 (BCA)</p>
			<p>WA 085875644805</p>
				<p><i style="color: blue;border-bottom: 1px solid blue;">Melayani COD dan bisa juga kirim paket</i></p>
			<br>
			<h2>HAPPY SHOPPING :)</h2>
		</div>
	</div>
</div>

<div class="konten">

<div class="label">Terbaru</div>

	<div class="r">

<?php while($row = mysqli_fetch_assoc($tampil)){ ?>
		<div class="k4">
			<div class="post">
				<p><?= $row['nama']  ?></p>
				<div class="gambar">
					<a href="detail.php?id=<?= $row['id']?>"><img src="<?= $row['gambar']  ?>" alt=""></a>
				</div>
				<h3>Rp <?= number_format($row['harga'])  ?></h3>
				<div class="cap">
					<a href="detail.php?id=<?= $row['id']?>" class="tmbl putih">Detail</a>
					<a href="ker.php?ker=add&id=<?= $row['id'] ?>" class="tmbl biru">Pesan Sekarang</a>
				</div>
			</div>
		</div>
<?php } ?>

	</div>
</div>


<?php 
footerku();
 ?>