<?php 
require_once 'pembeli/conn.php';

?>
<?php function headerku(){ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>WarungKembang</title>
	<link rel="stylesheet" href="pembeli/css.css">
	<link rel="stylesheet" href="pembeli/style.css">
	<link rel="icon" type="img/png" href="img/logokembang.png">
</head>
<body>

<nav>
	<div class="konten">
	<b>Warungkembang |</b>
		<ul>
			<a href="index.php"><li>Beranda</li></a>
			<a href="produk.php?hal=bunga"><li>Tanaman hias</li></a>
			<a href="produk.php?hal=bibit"><li>Bibit buah</li></a>
			<a href="keranjang.php"><li>Keranjang <img src="img/cart2p.png" alt=""></li></a>
		</ul>
		<ul style="float: right;">
			<a href="admin/"><li><img src="img/akun.png" width="50px" style="float:left;">Login</li></a>
		</ul>
		<form action="produk.php" method="get">
			<input type="text" name="cari" placeholder="Ketikan keyword">
			<button>Cari</button>
		</form>
	</div>
</nav>
<?php } ?>

<?php 
$hal = isset($_GET['hal']) ? $_GET['hal'] : "bunga";
if($hal == "bunga"){$tag = 'bunga';}
elseif($hal == "bibit"){$tag = 'bibit';}
else{$tag = 'bibit';}
 ?>


<?php function footerku(){ ?>
<div class="fotb">
	&copy; Warungkembang
	<img src="img/logokembang.png" alt="" width="60px" align="center">
</div>
</body>
</html>
<?php } ?>