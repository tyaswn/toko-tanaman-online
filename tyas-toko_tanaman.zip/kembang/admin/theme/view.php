<?php 
require_once 'fungsi.php';
 ?>
<?php function headerku(){ ?>
<!DOCTYPE html>
<html>
<head>
	<title>admin</title>
	<link rel="stylesheet" type="text/css" href="theme/style.css">
	<link rel="icon" type="img/png" href="../img/logokembang.png">
</head>
<body>

<nav>

	<div class="brand">
		Hai <?= $_SESSION['nama'];  ?> !
	</div>

	<div class="konten">
		<ul>
			<a href="index.php"><li>Semua</li></a>
			<a href="add.php"><li>Tambah data</li></a>
			<a href="pembeli.php"><li>Pembeli</li></a>
			<a href="logout.php"><li>Logout</li></a>
		</ul>
		<form action="index.php" method="get">
			<input type="text" name="cari" placeholder="Ketik keyword pencarian...">
			<button>Cari</button>
		</form>
	</div>
</nav>
<?php } ?>


<?php function menu(){ ?>

<?php } ?>

<?php 
$hal = isset($_GET['hal']) ? $_GET['hal'] : "bunga";
if($hal == "bunga"){$tag = 'bunga';}
elseif($hal == "bibit"){$tag = 'bibit';}
else{$tag = 'bibit';}
 ?>

<?php function footerku(){ ?>

<div class="footer">
	&copy; warungkembang<img src="../img/logokembang.png" width="50px" align="center" >
</div>

</body>
</html>
<?php } ?>