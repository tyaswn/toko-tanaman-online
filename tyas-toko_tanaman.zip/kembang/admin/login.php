<?php 
require_once 'theme/fungsi.php';

if(isset($_SESSION['nama'])){
	header('Location: index.php');
}

if(isset($_POST['login'])){
	$nama = $_POST['nama'];
	$pass = $_POST['password'];

	if( !empty(trim($nama)) && !empty(trim($pass)) ){
		if(cek_user($nama, $pass)){
			$_SESSION['nama'] = $nama;
			header('Location: index.php');
		}else{
			header('Location: login.php');

		}
	}else{
		header('Location: login.php');

	}
}


 ?>

<style type="text/css">
*{
	margin: 0; padding: 0;
	font-family: "Segoe UI", sans-serif;
	max-width: 100% !important;
}
.login{
	width: 450px; height: 300px; margin: 10% auto;
	background-color: darkseagreen;
	padding: 10px;
}
.login p{
	display: block;
	text-align: center;
	font-size: 20px;
}
.login form{
	padding: 10px;
}
.login input{
	width: 100%; margin: 3px 0px;
	padding: 10px;
	border: none;
}
.login input[type="submit"]{
	background-color: #5cb85c;
	color: white; cursor: pointer;
}
.login input[type="submit"]:hover{
	background-color: #449d44;
}

body{
	background-image: url("../img/kembang1.jpg");
}
</style>
<div class="login">
	<center>
	<img src="../img/ucing.png" width="100px">
</center>
	<p><b style="border-bottom: 3px solid white; color: white;">Login Account<b></p>
	<br><br>
	<form method="post">
		<input type="text" name="nama" placeholder="Username">
		<input type="password" name="password" placeholder="Password">
		<input type="submit" name="login">
	</form>
</div>